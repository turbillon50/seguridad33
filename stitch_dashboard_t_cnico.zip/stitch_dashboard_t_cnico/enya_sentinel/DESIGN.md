---
name: Enya Sentinel
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  gutter: 24px
  margin: 32px
---

## Brand & Style

The design system is engineered for **ENYA OPS**, a security operations SaaS that demands absolute reliability and high-performance clarity. The brand personality is **authoritative, precise, and forward-leaning**, blending corporate stability with a futuristic edge.

The visual direction follows a **Corporate / Modern** aesthetic with "Pro-Tools" DNA—drawing inspiration from the structural rigor of Linear and the functional elegance of Stripe. It emphasizes a "Security First" mentality, utilizing a high-density information architecture that remains legible through generous structural whitespace and surgical precision in layout. The emotional response should be one of confidence and control, reassuring security operators that they are working with the most advanced tools in the field.

## Colors

The palette is anchored by **Corporate Blue (#2563EB)**, a color that signals trust and institutional strength. **Sky Blue (#0EA5E9)** is used for secondary actions and data visualizations, providing a lighter, more modern counterpoint.

While the default mode is Light for administrative clarity during daylight hours, the system is designed as a "Dark-First" capable architecture, reflecting the 24/7 nature of security operations. Semantic colors (Success, Warning, Danger) are high-chroma to ensure critical alerts are never missed, even at small sizes. All text-on-background combinations must meet WCAG AA standards for accessibility.

## Typography

The design system utilizes **Inter**, a typeface designed for screen legibility and technical clarity. The scale is built on a modular rhythm to ensure complex data tables and dashboards remain highly readable.

**Usage Guidelines:**
- **Headlines:** Reserved for page titles and high-level section headers. Uses tighter letter-spacing for a modern, compact look.
- **Body:** Standardized at 16px for primary reading and 14px for secondary metadata or dense data views.
- **Labels:** Small, all-caps labels are used for categories and data headers to provide visual distinction from content values.
- **Monospace (Alternative):** For technical identifiers (e.g., ticket IDs, IP addresses, or device serials), use a secondary monospaced font like *JetBrains Mono* to enhance scannability.

## Layout & Spacing

This design system employs a **12-column fluid grid** for desktop, optimized for 1440px viewports but scaling gracefully. The spacing logic is based on a **4px baseline grid**, ensuring that every element—from the smallest icon to the largest container—shares a mathematical relationship.

- **Desktop (12 columns):** 24px gutters, 32px side margins. High-density layouts use 16px internal padding for cards.
- **Tablet (8 columns):** 16px gutters, 24px side margins.
- **Mobile (4 columns):** 12px gutters, 16px side margins.

Content is organized using "Zonal Architecture": a fixed left navigation for global context, a top utility bar for search/notifications, and a fluid central canvas for task execution.

## Elevation & Depth

To achieve a "Stripe-grade" and "Apple-like" feel, elevation is conveyed through **Tonal Layers** and **Refined Ambient Shadows**. 

1.  **The Base Layer:** The background is the lowest level (Level 0).
2.  **Surface Level:** Cards and primary containers sit on Level 1, utilizing a subtle 1px border (#E5E7EB) and a soft, diffused shadow (0px 4px 12px rgba(0,0,0,0.05)).
3.  **Raised Level:** Hover states and active dropdowns move to Level 2, with a more pronounced shadow (0px 8px 24px rgba(0,0,0,0.08)) and a crisp 1px border.
4.  **Overlay Level:** Modals and global notifications occupy the highest level, using a backdrop blur (20px) on the obscured content to focus the user's attention.

Avoid heavy blacks in shadows; use tinted shadows that incorporate a fraction of the Primary Blue to maintain the corporate identity even in the depth markers.

## Shapes

The design system adopts a **Soft (0.25rem - 0.75rem)** roundedness profile. This specific radius provides a balance between the "sharpness" of technical tools and the "approachability" of premium modern software.

- **Standard Elements (Buttons, Inputs):** 6px (0.375rem).
- **Small Elements (Chips, Tags):** 4px (0.25rem).
- **Large Elements (Cards, Modals):** 12px (0.75rem).

Interactive elements should maintain these consistent radii to ensure a cohesive visual language. In data-heavy tables, individual cells remain sharp (0px) to maximize screen real estate, while the container card remains rounded.

## Components

### Buttons
- **Primary:** Solid #2563EB with white text. High-contrast, 6px radius.
- **Secondary:** Transparent with a 1px #E5E7EB border. Subtle hover state with a light grey fill.
- **Ghost:** No border or fill. Used for low-priority actions in toolbars.

### Input Fields
- Use a white background (light mode) with a 1px border.
- **Focus State:** 2px Blue #2563EB ring with a 2px offset.
- Labels sit above the field in `label-md` style.

### Chips & Badges
- **Status Badges:** Use a light tint of the semantic color (e.g., Success) as a background with dark semantic text (e.g., Dark Green text on Light Green background).
- **Interactive Chips:** Used for filtering, featuring a small 'x' for removal.

### Cards
- White background, 1px border, 12px corner radius.
- Headers within cards should have a subtle bottom border to separate controls from content.

### Data Tables
- Header rows use a light grey background (#F1F5F9) and `label-sm` typography.
- Row hover states use a very subtle blue tint to guide the eye without adding visual clutter.
- Incorporate "Sparklines" (mini-charts) directly in table cells for at-a-glance performance monitoring.

### Specialized Security Components
- **Live Feed Container:** A dark-themed video container with minimal overlays for camera streams.
- **Alert Banner:** A persistent, high-contrast bar for critical system warnings, appearing at the very top of the interface.